'use strict';

angular.module('cityapl',[
	//external component
	'ngMaterial',
	'ngMessages',
	'ngRoute',
	'ngResource',
	'ngCookies',
	//internal component
	'categoryList',
	'subcategoryList',
	'shopList',
	'shopDetail',
	'cityaplToolbar',
	'changePassword',
	]);