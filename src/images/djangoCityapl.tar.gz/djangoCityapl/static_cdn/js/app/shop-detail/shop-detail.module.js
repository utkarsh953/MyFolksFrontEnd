'use strict';

angular.module('shopDetail',['shop.services','feedback.services','pricing.services']);