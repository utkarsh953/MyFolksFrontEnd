'use strict';

angular.module('city.services',[]);