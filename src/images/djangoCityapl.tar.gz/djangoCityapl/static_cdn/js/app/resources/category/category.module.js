'use strict';

angular.module('category.services',[]);