'use strict';

angular.module('feedback.services',[]);