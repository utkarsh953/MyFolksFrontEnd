import re
import requests
from bs4 import BeautifulSoup
import xlsxwriter

# request params
# url:https://m.indiamart.com/isearch.php?s=pharmaceutical
# pg:2
# startpage:14
# autofetch:true
def scrapeData():
	shopNum = 1
	pageNo = 1
	startPage = 0
	url = "https://m.indiamart.com/isearch.php?s=pharmaceutical"
	workbook = xlsxwriter.Workbook('phrama.xlsx')
	worksheet = workbook.add_worksheet()
	row = 0
	#url name companyName phoneNo turnOver
	worksheet.write(row, 0, "Id")
	worksheet.write(row, 1, "URL")
	worksheet.write(row, 2, "Company Name")
	worksheet.write(row, 3, "Owner Name")
	worksheet.write(row, 4, "Phone no.")
	worksheet.write(row, 5, "Turnover")
	row+=1
	for i in range(2):
		try:
			# print("reaching")
			data = {
			'url':url,
			'pg':pageNo,
			'startpage':startPage,
			'autofetch':True
			}
			# print("WEWE")
			rData = requests.post(url, data = data)
			rText = rData.text
			soup = BeautifulSoup(rText,'html.parser')
			# list_pg1_13
			ids = []
			for i in range(1,14):
				tmp = 'list_pg'+str(pageNo)+'_'+str(i)
				ids.append(tmp)
			# print(ids)
			for id_ in ids:
				print("Fetching data number ",shopNum)
				shopNum+=1
				try:
					# print("idid")
					finalData = {}
					div  = soup.find(id=id_)
					div = div.find(class_="mnht99")
					pData = div.select('p')
					companyUrl = pData[0].select('a')[0]['href']
					companyDetail = pData[1].select('a')[0]
					finalData['companyName'] = (companyDetail.get_text().strip())
					# print(companyUrl)
					finalData['url'] = companyUrl
					# print("AS")
					shopDataReq = requests.get(companyUrl)
					shopDataReq = shopDataReq.text
					newSoup = BeautifulSoup(shopDataReq,'html.parser')
					contactNo = newSoup.find(id='noncalling_sup')
				#	print(contactNo)
					contactNo = re.findall(r'\+91\-[987]\d{9}',str(contactNo))[0]
					finalData['contactNo'] = contactNo
					div = newSoup.find(id="showme")
					try:
						div = div.findAll('p', {'class' : 'fwn'})
						finalData['name'] = (div[0].get_text())
						for data in div:
							data = data.get_text()
							if 'crore' in data.lower():
								finalData['turnover'] = data
					except:
						print("error")
					if 'turnover' in finalData.keys():
						print (finalData)
						worksheet.write(row, 0, row)
						worksheet.write(row, 1, finalData['url'])
						worksheet.write(row, 2, finalData['companyName'])
						worksheet.write(row, 3, finalData['name'])
						worksheet.write(row, 4, finalData['contactNo'])
						worksheet.write(row, 5, finalData['turnover'])
						row+=1
					print("success")
				except:
					print("error in fetching data")
			pageNo+=1
			startPage+=14
		except:
			print("error in page")
	workbook.close()
	print("done")
try:
	scrapeData()
except:
	workbook.close()
#url name companyName phoneNo turnOver
