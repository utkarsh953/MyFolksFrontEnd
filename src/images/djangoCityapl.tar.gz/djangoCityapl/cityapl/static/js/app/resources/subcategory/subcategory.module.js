'use strict';

angular.module('subcategory.services',[]);