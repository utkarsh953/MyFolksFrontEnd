'use strict';

angular.module('shop.services',[]);
