'use strict';

angular.module('pricing.services',[]);