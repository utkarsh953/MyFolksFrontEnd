'use strict';

angular.module('subcategoryList',['subcategory.services']);