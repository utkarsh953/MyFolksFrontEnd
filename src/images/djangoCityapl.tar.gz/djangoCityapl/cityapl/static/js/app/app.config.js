'use strict';

angular.module('cityapl').
	config(
		function($locationProvider,$routeProvider,$mdThemingProvider,$resourceProvider){
		$resourceProvider.defaults.stripTrailingSlashes = false;
		$locationProvider.html5Mode({enabled:true})
		$routeProvider.
			when("/",{
				template:"<category-list></category-list>"
			}).
			when("/category/:id",{
				template:"<subcategory-list></subcategory-list>"
			}).
			when("/:subcatid/shops",{
				template:"<shop-list></shops-list>"
			}).
			when("/shop/:slug",{
				template:"<shop-detail></shop-detail>"
			}). //implementingg searching and listing of shops from same component
			when("/search/:search",{
				template:"<shop-list></shops-list>"
			}).when("/changepassword",{
				template:"<change-password></change-password>"
			}).
			otherwise({
				template:"NOT FOUND"
			});

		$mdThemingProvider.
			theme('default').
			primaryPalette('teal').
			accentPalette('orange');
		});