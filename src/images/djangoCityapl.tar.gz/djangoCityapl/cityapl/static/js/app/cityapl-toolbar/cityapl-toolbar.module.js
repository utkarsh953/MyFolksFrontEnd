'use strict';

angular.module('cityaplToolbar',['category.services','city.services']);