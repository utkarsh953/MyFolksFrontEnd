'use strict';

angular.module('shopList',['shop.services']);