'use strict';

angular.module('categoryList',['category.services']);