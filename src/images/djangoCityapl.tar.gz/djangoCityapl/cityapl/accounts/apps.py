from django.apps import AppConfig


class AccoutnsConfig(AppConfig):
    name = 'accoutns'
