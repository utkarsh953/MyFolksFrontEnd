from django.http import HttpResponse
from django.shortcuts import render
from .models import (
	Category,
	SubCategory,
	FilterTag
	)

# Create your views here.

# def addCity(request):
# 	return render(request,'shop/addCityTemplate.html',{})

# def viewCatsAndSubcats(request):
# 	categories = Category.objects.order_by('name')
# 	subCategories = SubCategory.objects.order_by('name')
# 	context = {
# 		'categories':categories,
# 		'subCategories':subCategories
# 	}
# 	return render(request,'shop/viewCat.html',context)