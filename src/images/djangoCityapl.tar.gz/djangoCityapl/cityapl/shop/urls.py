from django.conf.urls import url

urlpatterns = [
	# url(r'^$',viewCatsAndSubcats,name="catandsubcats"),
 #    url(r'^addcity/$',addCity),
]
